package com.jit.pkg;
import java.io.IOException;
import java.io.PrintWriter;
 
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Myservlet1")
public class Myservlet1 extends HttpServlet {
	
	protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
		 }
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws IOException{
		
		String username = request.getParameter("username");
        String password = request.getParameter("password");
        String gender = request.getParameter("gender");
        String language = request.getParameter("language");
        String feedback = request.getParameter("feedback");
        String jobList = request.getParameter("jobSearch");
        
        
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		System.out.println("username: " + username);
        System.out.println("password: " + password);
        System.out.println("Gender: " + gender);
        
        System.out.println("Feedback: " + feedback);
        System.out.println("Job category: " + jobList);
        System.out.println("Language: " + language);
        
       
		PrintWriter writer = response.getWriter();
		
		 String htmlRespone = "<html>";
	        htmlRespone += "<h2>Your username is: " + username + "<br/>";      
	        htmlRespone += "Your password is: " + password + "</h2>";    
	        htmlRespone += "</html>";
		
		writer.println(htmlRespone);
	}

}
